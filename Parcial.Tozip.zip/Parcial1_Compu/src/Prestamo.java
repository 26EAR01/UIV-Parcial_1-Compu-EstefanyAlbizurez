import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.*;
import java.awt.Color;
import java.awt.event.*;
import java.text.DecimalFormat;

public class Prestamo extends JFrame {

    // --- Componentes de la Interfaz ---
    private JMenuBar barraMenus;
    private JMenuItem itemInstruc, itemSalir, itemAnios, itemMeses, itemAcercaDe;
    private JTextField txtCredito, txtPeriodoMax, txtPeriodoMin, txtInteresMax, txtInteresMin;
    private JComboBox<String> cbxIncremento;
    private JButton btnPagos, btnAmortizacion;
    private JPanel panelDuracion, panelInteres;
    private JScrollPane scrollPane;
    private JTable tablaDatos, tablaCabeceras;

    // --- Variables de control ---
    private int tiposInteres = 18;
    private int columnasTiempo = 4;
    private double credito, pagoMensual;
    private boolean tablaPagosGenerada = false;

    public Prestamo() {
        setTitle("Préstamo bancario");
        setSize(485, 385);
        setResizable(false);
        setLocationRelativeTo(null);
        
        iniciarComponentes();
        
        txtCredito.setText("6000");
        txtPeriodoMax.setText("1");
        txtPeriodoMin.setText("1");
        txtInteresMax.setText("10.00");
        txtInteresMin.setText("0.00");
        cbxIncremento.setSelectedIndex(2);
        
        crearTabla(tiposInteres, columnasTiempo + 1);
    }

    private void iniciarComponentes() {
        getContentPane().setLayout(null);

        barraMenus = new JMenuBar();
        JMenu menuOpciones = new JMenu("Opciones");
        menuOpciones.setMnemonic('O');
        
        itemInstruc = new JMenuItem("Instrucciones...");
        itemInstruc.setMnemonic('I');
        itemInstruc.addActionListener(e -> mostrarInstrucciones());
        
        itemSalir = new JMenuItem("Salir");
        itemSalir.setMnemonic('S');
        itemSalir.addActionListener(e -> System.exit(0));

        JMenu menuPrestamoEn = new JMenu("Préstamo en...");
        menuPrestamoEn.setMnemonic('P');
        itemAnios = new JMenuItem("Años");
        itemAnios.setEnabled(false);
        itemMeses = new JMenuItem("Meses");
        
        ActionListener cambiarTiempo = e -> {
            boolean esAnio = e.getSource() == itemAnios;
            itemAnios.setEnabled(!esAnio);
            itemMeses.setEnabled(esAnio);
            panelDuracion.setBorder(new TitledBorder(esAnio ? "Años del préstamo" : "Meses del préstamo"));
        };
        itemAnios.addActionListener(cambiarTiempo);
        itemMeses.addActionListener(cambiarTiempo);
        
        menuPrestamoEn.add(itemAnios);
        menuPrestamoEn.add(itemMeses);
        
        menuOpciones.add(itemInstruc);
        menuOpciones.add(new JSeparator());
        menuOpciones.add(menuPrestamoEn);
        menuOpciones.add(itemSalir);
        barraMenus.add(menuOpciones);

        JMenu menuAyuda = new JMenu("Ayuda");
        itemAcercaDe = new JMenuItem("Acerca de Préstamo...");
        itemAcercaDe.addActionListener(e -> JOptionPane.showMessageDialog(this, 
            "Informacion del estudiante\n\n" +
            "Desarrollado por:\n" +
            "Estefany Alejandra Albizurez Rodas\n" +
            "Cuarto bachillerato en ciencias y letras\n" +
            "con orientación en computación.", 
            "Acerca de Préstamo", JOptionPane.INFORMATION_MESSAGE));
        menuAyuda.add(itemAcercaDe);
        barraMenus.add(menuAyuda);
        
        setJMenuBar(barraMenus);

        JLabel lblCredito = new JLabel("Crédito:", SwingConstants.RIGHT);
        lblCredito.setBounds(15, 10, 50, 16);
        txtCredito = new JTextField();
        txtCredito.setHorizontalAlignment(JTextField.RIGHT);
        txtCredito.setBounds(65, 10, 105, 20);

        panelDuracion = new JPanel(null);
        panelDuracion.setBorder(new TitledBorder("Años del préstamo"));
        panelDuracion.setBounds(10, 35, 160, 80);
        
        JLabel lblMaxPer = new JLabel("Máximo:");
        lblMaxPer.setBounds(10, 20, 55, 16);
        txtPeriodoMax = new JTextField();
        txtPeriodoMax.setHorizontalAlignment(JTextField.RIGHT);
        txtPeriodoMax.setBounds(75, 20, 80, 20);
        
        JLabel lblMinPer = new JLabel("Mínimo:");
        lblMinPer.setBounds(10, 50, 55, 16);
        txtPeriodoMin = new JTextField();
        txtPeriodoMin.setHorizontalAlignment(JTextField.RIGHT);
        txtPeriodoMin.setBounds(75, 50, 80, 20);
        
        panelDuracion.add(lblMaxPer); panelDuracion.add(txtPeriodoMax);
        panelDuracion.add(lblMinPer); panelDuracion.add(txtPeriodoMin);

        panelInteres = new JPanel(null);
        panelInteres.setBorder(new TitledBorder("Tipo de interés"));
        panelInteres.setBounds(5, 130, 165, 115);
        
        JLabel lblMaxInt = new JLabel("% máximo:");
        lblMaxInt.setBounds(10, 20, 75, 16);
        txtInteresMax = new JTextField();
        txtInteresMax.setHorizontalAlignment(JTextField.RIGHT);
        txtInteresMax.setBounds(90, 20, 65, 20);
        
        JLabel lblMinInt = new JLabel("% mínimo:");
        lblMinInt.setBounds(10, 50, 75, 16);
        txtInteresMin = new JTextField();
        txtInteresMin.setHorizontalAlignment(JTextField.RIGHT);
        txtInteresMin.setBounds(90, 50, 65, 20);
        
        JLabel lblInc = new JLabel("Incremento:");
        lblInc.setBounds(10, 80, 75, 16);
        cbxIncremento = new JComboBox<>(new String[]{"0.10", "0.25", "0.50", "1.00"});
        cbxIncremento.setBounds(90, 80, 65, 20);
        
        panelInteres.add(lblMaxInt); panelInteres.add(txtInteresMax);
        panelInteres.add(lblMinInt); panelInteres.add(txtInteresMin);
        panelInteres.add(lblInc); panelInteres.add(cbxIncremento);

        btnPagos = new JButton("Pagos");
        btnPagos.setBounds(10, 255, 155, 26);
        btnPagos.addActionListener(e -> calcularPagos());
        
        btnAmortizacion = new JButton("Amortización");
        btnAmortizacion.setBounds(10, 295, 155, 26);
        btnAmortizacion.setEnabled(false);
        btnAmortizacion.addActionListener(e -> calcularAmortizacion());

        scrollPane = new JScrollPane();
        scrollPane.setBounds(180, 10, 290, 310);

        getContentPane().add(lblCredito);
        getContentPane().add(txtCredito);
        getContentPane().add(panelDuracion);
        getContentPane().add(panelInteres);
        getContentPane().add(btnPagos);
        getContentPane().add(btnAmortizacion);
        getContentPane().add(scrollPane);
    }

    private void crearTabla(int filas, int cols) {
        AbstractTableModel modeloBase = new AbstractTableModel() {
            Object[][] datos = new Object[filas][cols];
            String[] cabeceras = new String[cols];
            
            @Override public int getRowCount() { return datos.length; }
            @Override public int getColumnCount() { return cabeceras.length; }
            @Override public String getColumnName(int col) { return cabeceras[col] == null ? "" : cabeceras[col]; }
            @Override public Object getValueAt(int fila, int col) { return datos[fila][col]; }
            @Override public void setValueAt(Object val, int fila, int col) { datos[fila][col] = val; }
            @Override public boolean isCellEditable(int fila, int col) { return col > 0; }
        };

        DefaultTableColumnModel modeloColumnas = new DefaultTableColumnModel() {
            boolean primera = true;
            @Override public void addColumn(TableColumn col) {
                if (primera) { primera = false; return; }
                col.setMinWidth(110);
                super.addColumn(col);
            }
        };

        DefaultTableColumnModel modeloCabeceras = new DefaultTableColumnModel() {
            boolean primera = true;
            @Override public void addColumn(TableColumn col) {
                if (primera) {
                    col.setMaxWidth(55);
                    super.addColumn(col);
                    primera = false;
                }
            }
        };

        tablaDatos = new JTable(modeloBase, modeloColumnas);
        tablaCabeceras = new JTable(modeloBase, modeloCabeceras);
        
        tablaDatos.createDefaultColumnsFromModel();
        tablaCabeceras.createDefaultColumnsFromModel();
        
        tablaDatos.setSelectionModel(tablaCabeceras.getSelectionModel());
        tablaCabeceras.setBackground(Color.lightGray);
        tablaDatos.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tablaCabeceras.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        tablaDatos.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (tablaPagosGenerada && tablaDatos.getSelectedRow() != -1 && tablaDatos.getSelectedColumn() != -1) {
                    Object val = tablaDatos.getValueAt(tablaDatos.getSelectedRow(), tablaDatos.getSelectedColumn() + 1);
                    if (val != null) {
                        try {
                            String textoLimpio = val.toString().replace(" ", "").replace(",", "");
                            pagoMensual = Double.parseDouble(textoLimpio);
                            btnAmortizacion.setEnabled(true);
                        } catch (Exception ex) {}
                    }
                }
            }
        });

        scrollPane.setViewportView(tablaDatos);
        JViewport viewportCabecera = new JViewport();
        viewportCabecera.setView(tablaCabeceras);
        viewportCabecera.setPreferredSize(tablaCabeceras.getMaximumSize());
        scrollPane.setRowHeader(viewportCabecera);
    }

    private void mostrarInstrucciones() {
        JOptionPane.showMessageDialog(this, 
            "Introduzca el crédito, la duración del préstamo y el tipo\nde interés. Pulse el botón [Pagos] para visualizar\nlos pagos mensuales en la rejilla.\n\nElija un pago mensual y pulse el botón [Amortización]\npara visualizar el plan de amortización.", 
            "Instrucciones", JOptionPane.INFORMATION_MESSAGE);
    }

    private void calcularPagos() {
        try {
            credito = Double.parseDouble(txtCredito.getText());
            int pMin = Integer.parseInt(txtPeriodoMin.getText());
            int pMax = Integer.parseInt(txtPeriodoMax.getText());
            double iMin = Double.parseDouble(txtInteresMin.getText());
            double iMax = Double.parseDouble(txtInteresMax.getText());
            double inc = Double.parseDouble((String) cbxIncremento.getSelectedItem());

            if (credito <= 0 || pMin <= 0 || pMax <= 0 || iMin < 0 || iMax < iMin) throw new Exception();

            tiposInteres = (int) ((iMax - iMin) / inc) + 1;
            columnasTiempo = (pMax - pMin) + 1;
            
            crearTabla(Math.max(tiposInteres, 18), Math.max(columnasTiempo, 4) + 1);

            DecimalFormat dfPorcentaje = new DecimalFormat("0.00");
            DecimalFormat dfMoneda = new DecimalFormat("#,##0.00");

            for (int f = 0; f < tiposInteres; f++) {
                tablaCabeceras.setValueAt(" " + dfPorcentaje.format(iMin + (inc * f)) + "%", f, 0);
            }

            String sufijo = itemAnios.isEnabled() ? " meses" : " años";
            int multiplicador = itemAnios.isEnabled() ? 1 : 12;

            for (int c = 0; c < columnasTiempo; c++) {
                tablaDatos.getColumnModel().getColumn(c).setHeaderValue((pMin + c) + sufijo);
            }
            scrollPane.repaint();

            for (int f = 0; f < tiposInteres; f++) {
                double interesDecimal = (iMin + (inc * f)) / 100 / 12;
                
                for (int c = 0; c < columnasTiempo; c++) {
                    int totalMeses = (pMin + c) * multiplicador;
                    double cuota;
                    
                    if (interesDecimal == 0) {
                        cuota = credito / totalMeses;
                    } else {
                        cuota = credito * (interesDecimal / (1 - Math.pow(1 + interesDecimal, -totalMeses)));
                    }
                    tablaDatos.getModel().setValueAt("  " + dfMoneda.format(cuota), f, c + 1);
                }
            }
            tablaPagosGenerada = true;
            btnAmortizacion.setEnabled(false);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Datos no válidos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void calcularAmortizacion() {
        int fila = tablaDatos.getSelectedRow();
        int colReal = tablaDatos.getSelectedColumn() + 1;

        String valInteres = tablaCabeceras.getValueAt(fila, 0).toString().replace("%", "").trim();
        double interesDecimal = Double.parseDouble(valInteres) / 100 / 12;

        String cabeceraTiempo = tablaDatos.getColumnModel().getColumn(colReal - 1).getHeaderValue().toString();
        int tiempoBase = Integer.parseInt(cabeceraTiempo.split(" ")[0]);
        int totalMeses = itemAnios.isEnabled() ? tiempoBase : tiempoBase * 12;

        crearTabla(Math.max(totalMeses, 18), 5);

        String[] titulos = {"Capital", "Intereses", "Capital pdte.", "Total intereses"};
        for (int i = 0; i < 4; i++) {
            tablaDatos.getColumnModel().getColumn(i).setHeaderValue(titulos[i]);
        }
        scrollPane.repaint();

        DecimalFormat df = new DecimalFormat("#,##0.00");
        double creditoPendiente = credito;
        double totalInteresesAcumulados = 0;

        for (int mes = 0; mes < totalMeses; mes++) {
            double interesMes = creditoPendiente * interesDecimal;
            double amortizacion = pagoMensual - interesMes;
            creditoPendiente -= amortizacion;
            totalInteresesAcumulados += interesMes;

            tablaCabeceras.setValueAt(String.valueOf(mes + 1), mes, 0);
            tablaDatos.getModel().setValueAt(" " + df.format(amortizacion), mes, 1);
            tablaDatos.getModel().setValueAt(" " + df.format(interesMes), mes, 2);
            tablaDatos.getModel().setValueAt(" " + df.format(Math.abs(creditoPendiente)), mes, 3);
            tablaDatos.getModel().setValueAt(" " + df.format(totalInteresesAcumulados), mes, 4);
        }
        
        btnAmortizacion.setEnabled(false);
        tablaPagosGenerada = false;
    }

    public static void main(String args[]) {
        SwingUtilities.invokeLater(() -> new Prestamo().setVisible(true));
    }
}